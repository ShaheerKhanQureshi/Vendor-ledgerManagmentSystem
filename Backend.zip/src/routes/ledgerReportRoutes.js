// // routes/ledgerReportRoutes.js
// import express from 'express';
// import { generateLedgerReport } from '../controllers/ledgerReportController.js'; // Import the controller

// const router = express.Router();

// // Route to generate the ledger report by vendor name
// router.get('/ledger-report/:vendor_name', generateLedgerReport);

// export default router;
